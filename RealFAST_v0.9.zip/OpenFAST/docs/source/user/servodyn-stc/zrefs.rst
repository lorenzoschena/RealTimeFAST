.. only:: html
   
   References
   ----------

.. bibliography:: StC_Refs.bib
   :labelprefix: stc-
