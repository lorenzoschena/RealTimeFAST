.. _ep_appendix_A:

Example Files
=============

Examples of inputs files are given below:

- `ExtPtfm Module input file <https://github.com/OpenFAST/r-test/blob/main/glue-codes/openfast/5MW_OC4Jckt_ExtPtfm/ExtPtfm.dat>`_

- `Superelement input file <https://github.com/OpenFAST/r-test/blob/main/glue-codes/openfast/5MW_OC4Jckt_ExtPtfm/ExtPtfm_SE.dat>`_

