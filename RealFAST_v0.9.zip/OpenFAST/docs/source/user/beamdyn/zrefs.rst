.. only:: html
   
   References
   ----------

.. bibliography:: references.bib



