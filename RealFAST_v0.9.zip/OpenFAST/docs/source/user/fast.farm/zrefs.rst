.. only:: html
   
   References
   ----------

.. bibliography:: bibliography.bib
   :labelprefix: ff-


