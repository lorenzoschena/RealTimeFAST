.. _FF:App:Input:

FAST.Farm Primary Input File
============================

When a default value is available,
``DEFAULT`` may be used instead of the value.

**Check the regression test cases for updates to this input file.**

.. container::
   :name: Tab:FFinputfile

   .. literalinclude:: examples/FAST.Farm--input.dat
      :linenos:
      :language: none
