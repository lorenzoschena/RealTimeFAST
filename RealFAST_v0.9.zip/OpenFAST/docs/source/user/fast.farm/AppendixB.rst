.. _FF:App:Wind:

Ambient Wind File
=================

.. container::
   :name: Tab:AmbientWind

   .. literalinclude:: examples/AmbientWind.vtk
      :language: none
