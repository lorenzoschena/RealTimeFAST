.. _OLAF-Primary-Input-File:

Appendix A: OLAF Primary Input File
===================================


**Check the regression test cases for updates to this input file.**

.. container::
   :name: Tab:OLAFinputfile

   .. literalinclude:: ExampleFiles/ExampleFile--OLAF.dat
      :linenos:
      :language: none
