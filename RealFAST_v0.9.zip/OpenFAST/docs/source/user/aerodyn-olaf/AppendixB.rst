.. _Prescribed-Circulation-Input-File:

Appendix B: Prescribed Circulation Input File
=============================================

**Check the regression tests for updated versions of this file.**

.. container::
   :name: TabPrescribeCirc

   .. literalinclude:: ExampleFiles/ExampleFile--PrescribeCirc.txt
      :linenos:
      :language: none
