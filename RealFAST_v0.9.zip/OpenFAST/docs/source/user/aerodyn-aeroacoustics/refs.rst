.. only:: html
   
   References
   ----------

.. bibliography:: references.bib
   :labelprefix: aa-


