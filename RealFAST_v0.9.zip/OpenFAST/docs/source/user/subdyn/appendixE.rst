.. _sd_appendix_E:

Appendix E. Compiling Stand-Alone SubDyn
========================================

See the FAST documentation for instructions on how to compile SubDyn coupled to FAST.
Future versions of the manual will include compiling instructions for building the stand-alone SubDyn program.
