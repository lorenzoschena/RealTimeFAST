.. _sd_appendix_C:

Appendix C. OC4 Jacket SSI Input File
=====================================

SubDyn's SSI File 
:download:`(OC4 Jacket SSI File) <./examples/OC4_Jacket_SD_SSI.txt>`: 

This file includes information on the stiffness of embedded-pile/soil combination.
