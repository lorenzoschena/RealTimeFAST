.. only:: html
   
   References
   ----------

.. bibliography:: references_SD.bib



