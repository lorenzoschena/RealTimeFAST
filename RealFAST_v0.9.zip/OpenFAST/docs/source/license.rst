.. _license:

Licensing
=========

The OpenFAST software, including its underlying modules, are licensed under     `Apache
License Version 2.0 <http://www.apache.org/licenses/LICENSE-2.0>`_ open-source
license.
