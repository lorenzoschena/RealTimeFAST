# SuperController Module

## Overview
This is a pseudo module used to couple OpenFAST with SuperController;
it is considered part of the OpenFAST glue code
