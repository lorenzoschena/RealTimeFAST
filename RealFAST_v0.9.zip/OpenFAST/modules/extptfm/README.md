# ExtPtfm Module

## Overview
A module for external platform loading (m, c, k, f) in OpenFAST
