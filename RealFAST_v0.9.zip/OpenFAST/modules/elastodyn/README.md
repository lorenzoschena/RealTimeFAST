# ElastoDyn Module

## Overview
ElastoDyn is the structural dynamics module in the OpenFAST framework.
