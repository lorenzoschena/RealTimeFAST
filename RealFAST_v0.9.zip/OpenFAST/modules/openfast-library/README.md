# OpenFAST Library Module

## Overview
The OpenFAST Library contains all of the subroutines making up the OpenFAST
glue code. These subroutines coordinate the initialization, solving, and
data output for the multiphysics simulation.
