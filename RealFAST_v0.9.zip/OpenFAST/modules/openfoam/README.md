# OpenFOAM Module

## Overview
This is a pseudo module used to couple OpenFAST with OpenFOAM;
it is considered part of the OpenFAST glue code.
