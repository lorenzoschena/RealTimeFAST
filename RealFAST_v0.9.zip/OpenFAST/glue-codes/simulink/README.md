OpenFAST expects a set of channels passed from Simulink to the library.  The number channels may change between OpenFAST releases.

For list of control channels, see comments at end of source file modules/openfast-library/src/FAST_Library.h 

The examples included here inclue all the channels listed in the FAST_Library.h file.
