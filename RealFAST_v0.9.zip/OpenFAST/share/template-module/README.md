# OpenFAST Module Template 

This directory contains a template for modules within the OpenFAST Framework. 
